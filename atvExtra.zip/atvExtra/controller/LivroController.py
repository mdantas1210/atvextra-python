from repositories.LivroRepository import LivroRepository
class LivroController:
    """
    Classe para controlar o cadastro de livros.
    """
    @staticmethod
    def cadastrar_livro(livroT, livroA, livroP, livroQtd):
        """
        Função de cadastro de livros que trata um possível erro de espaços vazios.
        :param livroT:
        :param livroA:
        :param livroP:
        :param livroQtd:
        :return:
        """
        if livroT == "" or livroA == "" or livroP == "" or livroQtd == "":
            print("Escreva algo")
        else:
            try:
                LivroRepository.create(livroT, livroA, float(livroP), int(livroQtd))
            except ValueError as erro:
                print(erro)


