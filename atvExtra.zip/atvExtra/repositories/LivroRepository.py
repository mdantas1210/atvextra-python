import mysql.connector as mysql

class LivroRepository:
    """
    Esta classe representa o crud, e faz conexão com o banco MySQL.
    """
    @staticmethod
    def criar_conexao():
        """
        Estabelece conexão com o banco de dados.
        :return conexão com o banco:
        """
        conexao = mysql.connect(host="localhost", user="root", password="root", database="biblioteca")
        return conexao

    @staticmethod
    def create(titulo, autor, preco, num_exemplares):
        """
        Insere os valores relacionados para cada columa da tabela.
        :param titulo:
        :param autor:
        :param preco:
        :param num_exemplares:
        :return:
        """
        conexao = LivroRepository.criar_conexao()
        cursor = conexao.cursor()
        cursor.execute('INSERT INTO livros(titulo, autor, preco, num_exemplares) VALUES("{}","{}",{},{})'.format(titulo,autor,preco,num_exemplares))

        conexao.commit()

        cursor.close()
        conexao.close()

    @staticmethod
    def read():
        """
        Lista todos os valores contidos dentro de cada coluna da tabela Livros.
        :return lista dos livros registrados:
        """
        conexao = LivroRepository.criar_conexao()
        cursor = conexao.cursor()
        cursor.execute("SELECT * FROM livros")

        livrosBanco = cursor.fetchall()
        return livrosBanco

        cursor.close()
        conexao.close()

    @staticmethod
    def delete(id):
        """
        Deleta um livro da tabela através do seu id.
        :param id:
        :return:
        """
        conexao = LivroRepository.criar_conexao()
        cursor = conexao.cursor()
        cursor.execute("DELETE FROM livros where id_livro={}".format(id))

        conexao.commit()

        cursor.close()
        conexao.close()