
class Livro:
    """
    Classe que representa um livro na biblioteca.
    Os seguintes atributos são:
    titulo (str): título do livro;
    autor (str): autor do livro;
    preco (str): preco do livro;
    num_exemplares (int): número de exemplares disponíveis.
    """

    def __init__(self, titulo, autor, preco, num_exemplares):
        self.__titulo = titulo
        self.__autor = autor
        self.__preco = preco
        self.__num_exemplares = num_exemplares

    @property
    def titulo(self):
        """
        Representa o nome do livro.
        :return:
        """
        return self.__titulo

    @property
    def autor(self):
        """
        Representa o nome do autor.
        :return:
        """
        return self.__autor

    @property
    def preco(self):
        """
        Representa o preço do produto.
        :return:
        """
        return self.__preco

    @property
    def num_exemplares(self):
        """
        Representa a quantidade de livros no estoque.
        :return:
        """
        return self.__num_exemplares