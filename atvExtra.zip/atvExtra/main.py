from tkinter import *
from tkinter import ttk
from controller.LivroController import LivroController
from repositories.LivroRepository import LivroRepository

interface = Tk()
interface.title("Menu da Conhecer")
interface.geometry("500x250")
interface.config(bg="gray")

interfaceJ = Label(interface, text=" Bem-vindo a loja online da Conhecer, por favor selecione uma das opções abaixo:")
interfaceJ.grid(row=1, column=0, padx=10, pady=10)

def janela_cadastro():
    """
    Exibe janela para cadastro de livro.
    :return:
    """
    janela1 = Toplevel()
    janela1.title("Cadastro de Livros")
    janela1.geometry("500x500")
    janela1.config(bg="gray")

    def inserir_livro():
        """
        Comando para adicionar o título, autor, preço, e número de exemplares  do livro.
        :return:
        """
        livroT = textoLivroT.get()
        livroA = textoLivroA.get()
        livroP = textoLivroP.get()
        livroQtd = textoLivroQtd.get()
        LivroController.cadastrar_livro(livroT, livroA, livroP, livroQtd)


    caixaLivroT = Label(janela1, text="Título do Livro:")
    caixaLivroT.grid(row=1, column=0, padx=10, pady=10)

    textoLivroT = Entry(janela1, width=20)
    textoLivroT.grid(row=1, column=1, padx=10, pady=10)

    caixaLivroA = Label(janela1, text="Autor do Livro:")
    caixaLivroA.grid(row=2, column=0, padx=10, pady=10)

    textoLivroA = Entry(janela1, width=20)
    textoLivroA.grid(row=2, column=1, padx=10, pady=10)

    caixaLivroT = Label(janela1, text="Preço do Livro:")
    caixaLivroT.grid(row=3, column=0, padx=10, pady=10)

    textoLivroP = Entry(janela1, width=20)
    textoLivroP.grid(row=3, column=1, padx=10, pady=10)

    caixaLivroQtd = Label(janela1, text="Número de Exemplares do Livro:")
    caixaLivroQtd.grid(row=4, column=0, padx=10, pady=10)

    textoLivroQtd = Entry(janela1, width=20)
    textoLivroQtd.grid(row=4, column=1, padx=10, pady=10)

    botaoCadastro = Button(janela1, text="Cadastrar", command=inserir_livro)
    botaoCadastro.grid(row=5, column=0, padx=10, pady=10)

botao1 = Button(interface, text="Cadastro do Livro", command=janela_cadastro)
botao1.grid(row=2, column=0, padx=10, pady=10)

def janela_produtos():
    """
    Exibe a janela para visualização dos livros cadastrados.
    :return:
    """
    janela2 = Toplevel()
    janela2.title("Livros Disponíveis")
    janela2.geometry("500x500")
    janela2.config(bg="gray")

    def deletar_livro():
        """
        Comando relacionado ao botão de excluir livro da lista.
        :return:
        """
        del_item = listaProd.selection()
        for l in del_item:
            values = listaProd.item(l, 'values')
            livrosBanco = LivroRepository.read()
            for item in livrosBanco:
                if item[0] == int(values[0]):
                    LivroRepository.delete(int(item[0]))
                    listaProd.delete(l)



    TabelaProd = Label(janela2)
    TabelaProd.config(bg="#9b111e", width=40)
    TabelaProd.pack(side=LEFT,expand=True,padx=20)

    listaProd = ttk.Treeview(TabelaProd, columns=('Id','Título','Autor','Preço','Número de Exemplares'), show= 'headings')

    listaProd.heading('Id', text='ID')
    listaProd.heading('Título', text='Título')
    listaProd.heading('Autor', text='Autor')
    listaProd.heading('Preço', text='R$')
    listaProd.heading('Número de Exemplares', text='Quantidade')

    listaProd.column(0, width=50)
    listaProd.column(1, width=50)
    listaProd.column(2, width=50)
    listaProd.column(3, width=50)
    listaProd.column(4, width=50)

    listaProd.config(height=20)
    listaProd.pack()

    livrosBanco= LivroRepository.read()
    for item in livrosBanco:
        listaProd.insert('', 'end', values=("{}".format(item[0]), "{}".format(item[1]), "{}".format(item[2]), "{}".format(item[3]), "{}".format(item[4])))

    botaoExcluir = Button(janela2, text="Excluir Livro da Lista", command=deletar_livro)
    botaoExcluir.pack()

botao2 = Button(interface, text="Livros Disponíveis", command=janela_produtos)
botao2.grid(row=4, column=0, padx=10, pady=10)

interface.mainloop()